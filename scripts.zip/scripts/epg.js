#!/usr/bin/env node
/* eslint-env node */
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";
import { XMLParser } from "fast-xml-parser";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const OPEN_EPG_URL = "https://www.open-epg.com/files/france1.xml";
const SEP = /\s+(?:\/|v|vs|versus|–|—|-)\s+/i;

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
});

const sameUtcDay = (iso, ymd) => (iso || "").slice(0, 10) === ymd;
function sameParisDay(iso, ymd) {
  if (!iso) return false;
  const d = new Date(iso);
  const f = new Intl.DateTimeFormat("fr-FR", {
    timeZone: "Europe/Paris",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  const [dd, mm, yy] = f.format(d).split("/");
  return `${yy}-${mm}-${dd}` === ymd;
}
function parseXmltvTime(s) {
  const m =
    /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(?:\s*([+-]\d{4}))?$/.exec(
      s || ""
    );
  if (!m) return null;
  let [, Y, M, D, h, mn, sc, off] = m;
  let t = Date.UTC(+Y, +M - 1, +D, +h, +mn, +sc);
  if (off) {
    const sg = off.startsWith("-") ? -1 : 1,
      hh = +off.slice(1, 3),
      mm = +off.slice(3, 5);
    t -= sg * (hh * 60 + mm) * 60000;
  }
  return new Date(t).toISOString();
}
async function fetchXml(url) {
  const res = await fetch(url, { headers: { "User-Agent": "tv-sports/epg" } });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);
  const buf = new Uint8Array(await res.arrayBuffer());
  const isGz = url.endsWith(".gz") || (buf[0] === 0x1f && buf[1] === 0x8b);
  return isGz
    ? zlib.gunzipSync(buf).toString("utf-8")
    : Buffer.from(buf).toString("utf-8");
}
function getTitle(n) {
  const t = n?.title;
  if (!t) return "";
  if (typeof t === "string") return t;
  if (Array.isArray(t)) return String(t[0]?.["#text"] ?? t[0] ?? "");
  if (typeof t === "object") return String(t["#text"] ?? "");
  return "";
}
function canonChannel(s) {
  return String(s || "").replace(/\.[a-z]{2}$/i, "");
}
function buildWhitelist(json) {
  const entries = Array.isArray(json)
    ? json.flatMap((c) => [
        c.canon || c.name || c.id,
        ...(c.aliases || c.variants || []),
      ])
    : Object.entries(json).flatMap(([canon, vars]) => [canon, ...(vars || [])]);
  return new Set(
    entries.map((x) => x.toLowerCase().replace(/\.[a-z]{2}$/i, ""))
  );
}
function parseXmlEpg(xml, filterFn, wl) {
  const j = parser.parse(xml);
  const chans = j?.tv?.channel || [],
    progs = j?.tv?.programme || [];
  const channels = Array.isArray(chans) ? chans : [chans];
  const programmes = Array.isArray(progs) ? progs : [progs];
  const id2name = new Map();
  const firstName = (dn) =>
    dn
      ? typeof dn === "string"
        ? dn
        : Array.isArray(dn)
        ? String(dn[0]?.["#text"] ?? dn[0] ?? "")
        : typeof dn === "object"
        ? String(dn["#text"] ?? "")
        : ""
      : "";
  for (const c of channels) {
    const id = c?.["@_id"] || "";
    const name = firstName(c?.["display-name"]) || id;
    if (id) id2name.set(id, name);
  }
  const seen = new Set(),
    out = [];
  for (const p of programmes) {
    const start = parseXmltvTime(p?.["@_start"]);
    if (!start || !filterFn(start)) continue;
    const end = parseXmltvTime(p?.["@_stop"]);
    const title = getTitle(p).trim();
    const parts = title.split(SEP).map((s) => s?.trim());
    if (parts.length < 2 || !parts[0] || !parts[1]) continue; // garder uniquement les “matchs”
    const rawId = p?.["@_channel"] || "";
    const channel = canonChannel(id2name.get(rawId) || rawId);
    if (!wl.has(channel.toLowerCase())) continue;
    const key = `${channel.toLowerCase()}|${start}|${title}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({
      channel,
      start,
      end,
      title,
      epgHome: parts[0],
      epgAway: parts[1],
    });
  }
  return out.sort((a, b) => a.start.localeCompare(b.start));
}

export async function fetchEpg(day, useParis = false) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day || ""))
    throw new Error("fetchEpg(day): expected YYYY-MM-DD");
  const filter = (iso) => sameParisDay(iso, day);
  const [xml, channelsJson] = await Promise.all([
    fetchXml(OPEN_EPG_URL),
    fs
      .readFile(path.join(__dirname, "../config/channels.json"), "utf-8")
      .then(JSON.parse),
  ]);
  const whitelist = buildWhitelist(channelsJson);
  return parseXmlEpg(xml, filter, whitelist);
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  (async () => {
    const day = process.argv[2];
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day || "")) {
      console.error("Usage: node scripts/epg.js YYYY-MM-DD [--paris] [--keep]");
      process.exit(1);
    }
    const useParis = process.argv.includes("--paris");
    const data = await fetchEpg(day, useParis);
    const keep =
      process.env.KEEP_INTERMEDIATE === "1" || process.argv.includes("--keep");
    if (keep) {
      const outDir = path.join(__dirname, "../public/data");
      await fs.mkdir(outDir, { recursive: true });
      const outFile = path.join(outDir, `epg-${day}.json`);
      await fs.writeFile(outFile, JSON.stringify(data, null, 2), "utf-8");
      console.log(
        `✔ wrote public/data/epg-${day}.json (${data.length} programmes)`
      );
    } else {
      console.log(
        `ℹ epg.js: ${data.length} programmes for ${day} (not written; add --keep)`
      );
    }
  })().catch((e) => {
    console.error(e.message || String(e));
    process.exit(1);
  });
}
