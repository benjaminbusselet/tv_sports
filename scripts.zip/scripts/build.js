#!/usr/bin/env node
/* eslint-env node */
import { execFileSync as sh } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";

const KEEP = process.argv.includes("--keep");
const outDir = path.join("public", "data");
await fs.mkdir(outDir, { recursive: true });

const parisToday = () => {
  const s = new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Europe/Paris",
    dateStyle: "short",
  }).format(new Date());
  return s; // "YYYY-MM-DD"
};
const addDays = (iso, n) => {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000)
    .toISOString()
    .slice(0, 10);
};

const run = (...args) => sh("node", args.filter(Boolean), { stdio: "inherit" });

const start = parisToday(); // T (YYYY-MM-DD)
const days = Array.from({ length: 8 }, (_, i) => addDays(start, i)); // T..T+7
const keepArg = KEEP ? "--keep" : null;

// 1) Génération par jour (ICS → EPG → checkTeams → MERGE)
for (const day of days) {
  const ymd = day.replaceAll("-", "");
  run("scripts/ics.js", day, keepArg);
  run("scripts/epg.js", day, keepArg);
  run("scripts/checkTeams.js", ymd);
  run("scripts/merge.js", day, keepArg);
}

// 2) Purge des progs_*.json hors fenêtre T..T+7
const want = new Set(days.map((d) => `progs_${d.replaceAll("-", "")}.json`));
try {
  const files = await fs.readdir(outDir);
  await Promise.all(
    files
      .filter(
        (f) => f.startsWith("progs_") && f.endsWith(".json") && !want.has(f)
      )
      .map((f) => fs.unlink(path.join(outDir, f)))
  );
} catch {
  /* ignore */
}

console.log(
  `✔ build done for ${start} → ${days.at(-1)} (${
    KEEP ? "kept intermediates" : "finals only"
  })`
);
