#!/usr/bin/env node
/* eslint-env node */
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url),
  __dirname = path.dirname(__filename);
const day = ((p) =>
  /^\d{4}-\d{2}-\d{2}$/.test(p || "")
    ? p
    : (console.error("Usage: node scripts/merge.js YYYY-MM-DD"),
      process.exit(1)))(process.argv[2]);
const ymd = day.replaceAll("-", "");
const read = (p) =>
  fs
    .readFile(p, "utf-8")
    .then(JSON.parse)
    .catch(() => null);
const [ics, epg, teams] = await Promise.all([
  read(path.join(__dirname, `../public/data/ics-${day}.json`)),
  read(path.join(__dirname, `../public/data/epg-${day}.json`)),
  read(path.join(__dirname, "../config/teams.json")),
]);
const norm = (s) =>
  String(s || "")
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
const idx = {}; // idx[comp][aliasNorm]=teamICS
for (const [comp, map] of Object.entries(teams || {})) {
  idx[comp] = {};
  for (const [team, aliases] of Object.entries(map)) {
    idx[comp][norm(team)] = team;
    for (const a of aliases || []) idx[comp][norm(a)] = team;
  }
}
const asDate = (s) => new Date(s).getTime(),
  within = (a, b) => a && b && Math.abs(asDate(a) - asDate(b)) <= 3600000;
const mapEpg = (comp, p) => {
  const h = (idx[comp] || {})[norm(p.epgHome)],
    a = (idx[comp] || {})[norm(p.epgAway)];
  return h && a
    ? { home: h, away: a, channel: p.channel, start: p.start }
    : null;
};
const out = [];
for (const m of ics || []) {
  const comp = m.competition,
    H = norm(m.home),
    A = norm(m.away);
  const candidates = (epg || [])
    .map((p) => mapEpg(comp, p))
    .filter(Boolean)
    .filter((p) => {
      const ok =
        (norm(p.home) === H && norm(p.away) === A) ||
        (norm(p.home) === A && norm(p.away) === H);
      return ok && within(m.start, p.start);
    })
    .sort(
      (x, y) =>
        Math.abs(asDate(x.start) - asDate(m.start)) -
        Math.abs(asDate(y.start) - asDate(m.start))
    );
  const chan = candidates[0]?.channel ? [candidates[0].channel] : [];
  out.push({
    uid: m.uid,
    title: m.title,
    start: m.start,
    end: m.end,
    sport: m.sport,
    competition: comp,
    home: m.home,
    away: m.away,
    broadcasters: chan,
  });
}
await fs.mkdir(path.join(__dirname, "../public/data"), { recursive: true });
const outFile = path.join(__dirname, `../public/data/progs_${ymd}.json`);
await fs.writeFile(outFile, JSON.stringify(out, null, 2), "utf-8");
console.log(`✔ wrote public/data/progs_${ymd}.json (${out.length} events)`);
